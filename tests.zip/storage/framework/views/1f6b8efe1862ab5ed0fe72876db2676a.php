
<div class="flex justify-center mb-8">
    <img src="https://i0.wp.com/feedbackoysg.com/wp-content/uploads/2022/12/Big-logo.png" alt="Logo"
        class="h-20 w-auto">
</div>
<?php /**PATH C:\Users\user\Laravel\taxation-main\resources\views/components/application-logo.blade.php ENDPATH**/ ?>