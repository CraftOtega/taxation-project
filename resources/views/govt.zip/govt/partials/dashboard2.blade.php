@extends('govt.layouts.app')

@section('title', 'Dashboard')




@section('content')







@endsection

@push('scripts')

@endpush
