@extends('govt.layouts.app')

@section('title', 'Dashboard')




@section('content')



<livewire:govt.user.user-list/>





@endsection

@push('scripts')

@endpush
